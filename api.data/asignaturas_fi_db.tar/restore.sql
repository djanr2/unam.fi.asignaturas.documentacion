--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "ASIGNATURAS_FI_DB";
--
-- Name: ASIGNATURAS_FI_DB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "ASIGNATURAS_FI_DB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Spanish_Spain.1252' LC_CTYPE = 'Spanish_Spain.1252';


ALTER DATABASE "ASIGNATURAS_FI_DB" OWNER TO postgres;

\connect "ASIGNATURAS_FI_DB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE "ASIGNATURAS_FI_DB"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "ASIGNATURAS_FI_DB" IS 'Base de datos para administrar el tomo I de las carreras de la facultad de ingeniería. Con esta base de datos se lograra mostrar en un sistema web los mapas curriculares asi como los links a loa PDF de las asignaturas.';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acceso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acceso (
    id integer NOT NULL,
    date_creacion timestamp with time zone,
    date_actualizacion timestamp with time zone,
    usuario character varying(40),
    mail character varying(40),
    password_ciphed character varying(40),
    rol character varying(40),
    estado character varying(40),
    key character varying(40)
);


ALTER TABLE public.acceso OWNER TO postgres;

--
-- Name: Acceso_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Acceso_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Acceso_id_seq" OWNER TO postgres;

--
-- Name: Acceso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Acceso_id_seq" OWNED BY public.acceso.id;


--
-- Name: acceso_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acceso_token (
    id bigint NOT NULL,
    usuario character varying(40),
    token character varying(700),
    created timestamp with time zone,
    lifespan timestamp with time zone
);


ALTER TABLE public.acceso_token OWNER TO postgres;

--
-- Name: Access_token_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Access_token_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Access_token_id_seq" OWNER TO postgres;

--
-- Name: Access_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Access_token_id_seq" OWNED BY public.acceso_token.id;


--
-- Name: agrupacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agrupacion (
    id bigint NOT NULL,
    agrupacion character varying(20),
    nombre character varying(150)
);


ALTER TABLE public.agrupacion OWNER TO postgres;

--
-- Name: Agrupacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Agrupacion_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Agrupacion_id_seq" OWNER TO postgres;

--
-- Name: Agrupacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Agrupacion_id_seq" OWNED BY public.agrupacion.id;


--
-- Name: asignatura; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.asignatura (
    id bigint NOT NULL,
    clave numeric(5,0),
    carrera bigint,
    nombre character varying(300),
    horas_practicas numeric(3,1),
    horas_teoricas numeric(3,1),
    semestre character varying(15),
    orden numeric(2,0),
    nota character varying(10),
    optativa character varying(10),
    agrupacion character varying(20),
    tamano numeric(2,0),
    enlace_pdf character varying(200),
    color character varying(25),
    color_text character varying(25)
);


ALTER TABLE public.asignatura OWNER TO postgres;

--
-- Name: Asignatura_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Asignatura_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Asignatura_id_seq" OWNER TO postgres;

--
-- Name: Asignatura_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Asignatura_id_seq" OWNED BY public.asignatura.id;


--
-- Name: carrera; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carrera (
    id bigint NOT NULL,
    clave numeric(4,0),
    nombre character varying(70),
    year numeric(4,0),
    date_actualizacion timestamp with time zone
);


ALTER TABLE public.carrera OWNER TO postgres;

--
-- Name: Carrera_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Carrera_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Carrera_id_seq" OWNER TO postgres;

--
-- Name: Carrera_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Carrera_id_seq" OWNED BY public.carrera.id;


--
-- Name: estado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado (
    id integer NOT NULL,
    estado character varying(10),
    descripcion character varying(50)
);


ALTER TABLE public.estado OWNER TO postgres;

--
-- Name: Estado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Estado_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Estado_id_seq" OWNER TO postgres;

--
-- Name: Estado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Estado_id_seq" OWNED BY public.estado.id;


--
-- Name: rol_acceso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rol_acceso (
    id integer NOT NULL,
    rol character varying(10),
    descripcion character varying(50)
);


ALTER TABLE public.rol_acceso OWNER TO postgres;

--
-- Name: Rol_acceso_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Rol_acceso_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Rol_acceso_id_seq" OWNER TO postgres;

--
-- Name: Rol_acceso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Rol_acceso_id_seq" OWNED BY public.rol_acceso.id;


--
-- Name: seriacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seriacion (
    id bigint NOT NULL,
    carrera bigint,
    asignatura bigint,
    asignatura_seriada bigint,
    color character varying(10)
);


ALTER TABLE public.seriacion OWNER TO postgres;

--
-- Name: Seriacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Seriacion_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Seriacion_id_seq" OWNER TO postgres;

--
-- Name: Seriacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Seriacion_id_seq" OWNED BY public.seriacion.id;


--
-- Name: nota_mapa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nota_mapa (
    id bigint NOT NULL,
    carrera bigint NOT NULL,
    orden numeric(2,0),
    simbolo character varying(15),
    leyenda text
);


ALTER TABLE public.nota_mapa OWNER TO postgres;

--
-- Name: nota_mapa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nota_mapa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nota_mapa_id_seq OWNER TO postgres;

--
-- Name: nota_mapa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nota_mapa_id_seq OWNED BY public.nota_mapa.id;


--
-- Name: optativa_asignatura; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.optativa_asignatura (
    id integer NOT NULL,
    tabla bigint,
    asignatura bigint
);


ALTER TABLE public.optativa_asignatura OWNER TO postgres;

--
-- Name: optativa_asignatura_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.optativa_asignatura_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.optativa_asignatura_id_seq OWNER TO postgres;

--
-- Name: optativa_asignatura_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.optativa_asignatura_id_seq OWNED BY public.optativa_asignatura.id;


--
-- Name: optativa_categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.optativa_categoria (
    id integer NOT NULL,
    container bigint,
    orden numeric(2,0),
    titulo text DEFAULT ''::text NOT NULL,
    nota_head text DEFAULT ''::text NOT NULL,
    nota_foot text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.optativa_categoria OWNER TO postgres;

--
-- Name: optativa_categoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.optativa_categoria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.optativa_categoria_id_seq OWNER TO postgres;

--
-- Name: optativa_categoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.optativa_categoria_id_seq OWNED BY public.optativa_categoria.id;


--
-- Name: optativa_container; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.optativa_container (
    id integer NOT NULL,
    carrera bigint,
    orden numeric(2,0),
    titulo character varying(200) DEFAULT ''::character varying NOT NULL,
    nota_head text DEFAULT ''::text NOT NULL,
    nota_foot text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.optativa_container OWNER TO postgres;

--
-- Name: optativa_container_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.optativa_container_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.optativa_container_id_seq OWNER TO postgres;

--
-- Name: optativa_container_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.optativa_container_id_seq OWNED BY public.optativa_container.id;


--
-- Name: optativa_tabla; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.optativa_tabla (
    id integer NOT NULL,
    categoria bigint,
    orden numeric(2,0),
    titulo character varying(200) DEFAULT ''::character varying NOT NULL,
    nota_head text DEFAULT ''::text NOT NULL,
    nota_foot text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.optativa_tabla OWNER TO postgres;

--
-- Name: optativa_tabla_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.optativa_tabla_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.optativa_tabla_id_seq OWNER TO postgres;

--
-- Name: optativa_tabla_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.optativa_tabla_id_seq OWNED BY public.optativa_tabla.id;


--
-- Name: acceso id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acceso ALTER COLUMN id SET DEFAULT nextval('public."Acceso_id_seq"'::regclass);


--
-- Name: acceso_token id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acceso_token ALTER COLUMN id SET DEFAULT nextval('public."Access_token_id_seq"'::regclass);


--
-- Name: agrupacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agrupacion ALTER COLUMN id SET DEFAULT nextval('public."Agrupacion_id_seq"'::regclass);


--
-- Name: asignatura id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asignatura ALTER COLUMN id SET DEFAULT nextval('public."Asignatura_id_seq"'::regclass);


--
-- Name: carrera id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrera ALTER COLUMN id SET DEFAULT nextval('public."Carrera_id_seq"'::regclass);


--
-- Name: estado id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado ALTER COLUMN id SET DEFAULT nextval('public."Estado_id_seq"'::regclass);


--
-- Name: nota_mapa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_mapa ALTER COLUMN id SET DEFAULT nextval('public.nota_mapa_id_seq'::regclass);


--
-- Name: optativa_asignatura id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_asignatura ALTER COLUMN id SET DEFAULT nextval('public.optativa_asignatura_id_seq'::regclass);


--
-- Name: optativa_categoria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_categoria ALTER COLUMN id SET DEFAULT nextval('public.optativa_categoria_id_seq'::regclass);


--
-- Name: optativa_container id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_container ALTER COLUMN id SET DEFAULT nextval('public.optativa_container_id_seq'::regclass);


--
-- Name: optativa_tabla id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_tabla ALTER COLUMN id SET DEFAULT nextval('public.optativa_tabla_id_seq'::regclass);


--
-- Name: rol_acceso id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol_acceso ALTER COLUMN id SET DEFAULT nextval('public."Rol_acceso_id_seq"'::regclass);


--
-- Name: seriacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seriacion ALTER COLUMN id SET DEFAULT nextval('public."Seriacion_id_seq"'::regclass);


--
-- Data for Name: acceso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acceso (id, date_creacion, date_actualizacion, usuario, mail, password_ciphed, rol, estado, key) FROM stdin;
\.
COPY public.acceso (id, date_creacion, date_actualizacion, usuario, mail, password_ciphed, rol, estado, key) FROM '$$PATH$$/2971.dat';

--
-- Data for Name: acceso_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acceso_token (id, usuario, token, created, lifespan) FROM stdin;
\.
COPY public.acceso_token (id, usuario, token, created, lifespan) FROM '$$PATH$$/2977.dat';

--
-- Data for Name: agrupacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agrupacion (id, agrupacion, nombre) FROM stdin;
\.
COPY public.agrupacion (id, agrupacion, nombre) FROM '$$PATH$$/2965.dat';

--
-- Data for Name: asignatura; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.asignatura (id, clave, carrera, nombre, horas_practicas, horas_teoricas, semestre, orden, nota, optativa, agrupacion, tamano, enlace_pdf, color, color_text) FROM stdin;
\.
COPY public.asignatura (id, clave, carrera, nombre, horas_practicas, horas_teoricas, semestre, orden, nota, optativa, agrupacion, tamano, enlace_pdf, color, color_text) FROM '$$PATH$$/2967.dat';

--
-- Data for Name: carrera; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carrera (id, clave, nombre, year, date_actualizacion) FROM stdin;
\.
COPY public.carrera (id, clave, nombre, year, date_actualizacion) FROM '$$PATH$$/2963.dat';

--
-- Data for Name: estado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estado (id, estado, descripcion) FROM stdin;
\.
COPY public.estado (id, estado, descripcion) FROM '$$PATH$$/2975.dat';

--
-- Data for Name: nota_mapa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nota_mapa (id, carrera, orden, simbolo, leyenda) FROM stdin;
\.
COPY public.nota_mapa (id, carrera, orden, simbolo, leyenda) FROM '$$PATH$$/2986.dat';

--
-- Data for Name: optativa_asignatura; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.optativa_asignatura (id, tabla, asignatura) FROM stdin;
\.
COPY public.optativa_asignatura (id, tabla, asignatura) FROM '$$PATH$$/2985.dat';

--
-- Data for Name: optativa_categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.optativa_categoria (id, container, orden, titulo, nota_head, nota_foot) FROM stdin;
\.
COPY public.optativa_categoria (id, container, orden, titulo, nota_head, nota_foot) FROM '$$PATH$$/2981.dat';

--
-- Data for Name: optativa_container; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.optativa_container (id, carrera, orden, titulo, nota_head, nota_foot) FROM stdin;
\.
COPY public.optativa_container (id, carrera, orden, titulo, nota_head, nota_foot) FROM '$$PATH$$/2979.dat';

--
-- Data for Name: optativa_tabla; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.optativa_tabla (id, categoria, orden, titulo, nota_head, nota_foot) FROM stdin;
\.
COPY public.optativa_tabla (id, categoria, orden, titulo, nota_head, nota_foot) FROM '$$PATH$$/2983.dat';

--
-- Data for Name: rol_acceso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rol_acceso (id, rol, descripcion) FROM stdin;
\.
COPY public.rol_acceso (id, rol, descripcion) FROM '$$PATH$$/2973.dat';

--
-- Data for Name: seriacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.seriacion (id, carrera, asignatura, asignatura_seriada, color) FROM stdin;
\.
COPY public.seriacion (id, carrera, asignatura, asignatura_seriada, color) FROM '$$PATH$$/2969.dat';

--
-- Name: Acceso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Acceso_id_seq"', 12, true);


--
-- Name: Access_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Access_token_id_seq"', 18, true);


--
-- Name: Agrupacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Agrupacion_id_seq"', 78, true);


--
-- Name: Asignatura_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Asignatura_id_seq"', 7503, true);


--
-- Name: Carrera_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Carrera_id_seq"', 16, true);


--
-- Name: Estado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Estado_id_seq"', 5, true);


--
-- Name: Rol_acceso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Rol_acceso_id_seq"', 1, false);


--
-- Name: Seriacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Seriacion_id_seq"', 59, true);


--
-- Name: nota_mapa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nota_mapa_id_seq', 23, true);


--
-- Name: optativa_asignatura_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.optativa_asignatura_id_seq', 75, true);


--
-- Name: optativa_categoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.optativa_categoria_id_seq', 15, true);


--
-- Name: optativa_container_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.optativa_container_id_seq', 3, true);


--
-- Name: optativa_tabla_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.optativa_tabla_id_seq', 10, true);


--
-- Name: acceso Acceso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acceso
    ADD CONSTRAINT "Acceso_pkey" PRIMARY KEY (id);


--
-- Name: agrupacion Agrupacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agrupacion
    ADD CONSTRAINT "Agrupacion_pkey" PRIMARY KEY (id);


--
-- Name: asignatura Asignatura_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asignatura
    ADD CONSTRAINT "Asignatura_pkey" PRIMARY KEY (id);


--
-- Name: carrera Carrera_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrera
    ADD CONSTRAINT "Carrera_pkey" PRIMARY KEY (id);


--
-- Name: estado Estado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado
    ADD CONSTRAINT "Estado_pkey" PRIMARY KEY (id);


--
-- Name: rol_acceso Rol_acceso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol_acceso
    ADD CONSTRAINT "Rol_acceso_pkey" PRIMARY KEY (id);


--
-- Name: seriacion Seriacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seriacion
    ADD CONSTRAINT "Seriacion_pkey" PRIMARY KEY (id);


--
-- Name: agrupacion agrupacion_agrupacion_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agrupacion
    ADD CONSTRAINT agrupacion_agrupacion_unique UNIQUE (agrupacion);


--
-- Name: acceso mail_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acceso
    ADD CONSTRAINT mail_unique UNIQUE (mail);


--
-- Name: nota_mapa nota_mapa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota_mapa
    ADD CONSTRAINT nota_mapa_pkey PRIMARY KEY (id);


--
-- Name: optativa_asignatura optativa_asignatura_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_asignatura
    ADD CONSTRAINT optativa_asignatura_pkey PRIMARY KEY (id);


--
-- Name: optativa_categoria optativa_categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_categoria
    ADD CONSTRAINT optativa_categoria_pkey PRIMARY KEY (id);


--
-- Name: optativa_container optativa_container_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_container
    ADD CONSTRAINT optativa_container_pkey PRIMARY KEY (id);


--
-- Name: optativa_tabla optativa_tabla_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_tabla
    ADD CONSTRAINT optativa_tabla_pkey PRIMARY KEY (id);


--
-- Name: fki_agrupacion_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_agrupacion_fkey ON public.asignatura USING btree (agrupacion);


--
-- Name: fki_asignatura_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_asignatura_fkey ON public.seriacion USING btree (asignatura);


--
-- Name: fki_asignatura_seriada_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_asignatura_seriada_fkey ON public.seriacion USING btree (asignatura_seriada);


--
-- Name: fki_carrera_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_carrera_fkey ON public.asignatura USING btree (carrera);


--
-- Name: fki_categoria_container_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_categoria_container_fkey ON public.optativa_categoria USING btree (container);


--
-- Name: fki_container_carrera_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_container_carrera_fkey ON public.optativa_container USING btree (carrera);


--
-- Name: fki_optativa_asigantura_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_optativa_asigantura_fkey ON public.optativa_asignatura USING btree (asignatura);


--
-- Name: fki_optativa_tabla_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_optativa_tabla_fkey ON public.optativa_asignatura USING btree (tabla);


--
-- Name: fki_tabla_categoria_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_tabla_categoria_fkey ON public.optativa_tabla USING btree (categoria);


--
-- Name: asignatura agrupacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asignatura
    ADD CONSTRAINT agrupacion_fkey FOREIGN KEY (agrupacion) REFERENCES public.agrupacion(agrupacion) NOT VALID;


--
-- Name: seriacion asignatura_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seriacion
    ADD CONSTRAINT asignatura_fkey FOREIGN KEY (asignatura) REFERENCES public.asignatura(id) NOT VALID;


--
-- Name: seriacion asignatura_seriada_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seriacion
    ADD CONSTRAINT asignatura_seriada_fkey FOREIGN KEY (asignatura_seriada) REFERENCES public.asignatura(id) NOT VALID;


--
-- Name: asignatura carrera_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asignatura
    ADD CONSTRAINT carrera_fkey FOREIGN KEY (carrera) REFERENCES public.carrera(id) NOT VALID;


--
-- Name: CONSTRAINT carrera_fkey ON asignatura; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT carrera_fkey ON public.asignatura IS 'llave foranea al id de carrera';


--
-- Name: optativa_container carrera_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_container
    ADD CONSTRAINT carrera_fkey FOREIGN KEY (carrera) REFERENCES public.carrera(id) NOT VALID;


--
-- Name: optativa_categoria categoria_container_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_categoria
    ADD CONSTRAINT categoria_container_fkey FOREIGN KEY (container) REFERENCES public.optativa_container(id) NOT VALID;


--
-- Name: optativa_container container_carrera_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_container
    ADD CONSTRAINT container_carrera_fkey FOREIGN KEY (carrera) REFERENCES public.carrera(id) NOT VALID;


--
-- Name: optativa_asignatura optativa_asigantura_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_asignatura
    ADD CONSTRAINT optativa_asigantura_fkey FOREIGN KEY (asignatura) REFERENCES public.asignatura(id) NOT VALID;


--
-- Name: optativa_asignatura optativa_tabla_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_asignatura
    ADD CONSTRAINT optativa_tabla_fkey FOREIGN KEY (tabla) REFERENCES public.optativa_tabla(id) NOT VALID;


--
-- Name: optativa_tabla tabla_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optativa_tabla
    ADD CONSTRAINT tabla_categoria_fkey FOREIGN KEY (categoria) REFERENCES public.optativa_categoria(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

